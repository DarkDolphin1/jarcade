import { useState, useEffect, useCallback } from "react";
import { invoke } from "@tauri-apps/api/core";
import GameCard from "./components/GameCard";

interface Game {
  name: string;
  path: string;
  emoji?: string;
}

const EMOJIS = ["🎮","🕹️","⚔️","🏎️","🚀","🐍","🧱","🥷","🐠","⚡","🎯","🏆"];

const CATEGORIES = [
  { id: "users",   icon: "👤", label: "Users"    },
  { id: "settings",icon: "⚙️", label: "Settings" },
  { id: "photo",   icon: "📷", label: "Photo"    },
  { id: "music",   icon: "🎵", label: "Music"    },
  { id: "video",   icon: "📽️", label: "Video"    },
  { id: "game",    icon: "🎮", label: "Game",  active: true },
  { id: "network", icon: "🌐", label: "Network"  },
];

function Clock() {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="xmb-clock">
      {time.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}
      {"  "}
      {time.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}
    </div>
  );
}

function App() {
  const [games, setGames]               = useState<Game[]>([]);
  const [loading, setLoading]           = useState(true);
  const [selectedIdx, setSelectedIdx]   = useState(0);
  const [activeCat, setActiveCat]       = useState("game");
  const [launching, setLaunching]       = useState(false);

  const scanGames = async () => {
    setLoading(true);
    try {
      const list: Game[] = await invoke("scan_directory", { path: "../games" });
      setGames(list.map((g, i) => ({ ...g, emoji: EMOJIS[i % EMOJIS.length] })));
    } catch {
      // show empty state on error
      setGames([]);
    } finally {
      setLoading(false);
    }
  };

  const launchGame = async (path: string) => {
    if (launching) return;
    setLaunching(true);
    try { await invoke("launch_game", { gamePath: path }); }
    catch (err) { console.error(err); }
    finally { setTimeout(() => setLaunching(false), 2000); }
  };

  // Keyboard navigation
  const handleKey = useCallback((e: KeyboardEvent) => {
    if (e.key === "ArrowUp")    setSelectedIdx(i => Math.max(0, i - 1));
    if (e.key === "ArrowDown")  setSelectedIdx(i => Math.min(games.length - 1, i + 1));
    if (e.key === "Enter" && games[selectedIdx]) launchGame(games[selectedIdx].path);
  }, [games, selectedIdx, launching]);

  useEffect(() => {
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [handleKey]);

  useEffect(() => { scanGames(); }, []);

  const selectedGame = games[selectedIdx];

  // Arc radii for the background wave lines
  const arcs = [340, 420, 500, 580, 660, 740, 820];

  return (
    <div style={{ minHeight: "100vh", position: "relative", background: "#000814", overflow: "hidden" }}>

      {/* ── Animated background ── */}
      <div className="xmb-bg">
        <div className="xmb-wave" />
        <div className="xmb-arcs">
          {arcs.map((r, i) => (
            <div
              key={r}
              className="xmb-arc"
              style={{
                width: r * 2,
                height: r * 2,
                bottom: `-${r * 0.6}px`,
                left: `calc(22% - ${r}px)`,
                animationDelay: `${i * 1.5}s`,
                animationDuration: `${10 + i * 2}s`,
              }}
            />
          ))}
        </div>
      </div>

      {/* ── Top bar ── */}
      <div className="xmb-topbar">
        <div /> {/* spacer */}
        <Clock />
      </div>

      {/* ── Category row ── */}
      <div className="xmb-categories">
        {CATEGORIES.map((cat) => (
          <div
            key={cat.id}
            className={`xmb-cat ${activeCat === cat.id ? "active" : ""}`}
            onClick={() => setActiveCat(cat.id)}
          >
            <div className="xmb-cat-icon">{cat.icon}</div>
            <div className="xmb-cat-label">{cat.label}</div>
          </div>
        ))}
      </div>

      {/* Vertical line down from active category */}
      <div className="xmb-separator" />

      {/* ── Game list (vertical axis) ── */}
      <div className="xmb-items">
        {loading ? (
          <div style={{ color: "rgba(255,255,255,0.3)", fontFamily: "'Exo 2', sans-serif", fontWeight: 200, fontSize: 13, letterSpacing: ".1em" }}>
            Scanning library…
          </div>
        ) : games.length === 0 ? (
          <>
            <div className="xmb-item selected">
              <div className="xmb-item-icon"><span>📦</span></div>
              <div className="xmb-item-info">
                <div className="xmb-item-name">No Games Found</div>
                <div className="xmb-item-sub">Place .jar files in the games/ directory</div>
              </div>
            </div>
            <div
              className="xmb-item"
              onClick={scanGames}
              style={{ cursor: "pointer" }}
            >
              <div className="xmb-item-icon"><span>🔄</span></div>
              <div className="xmb-item-info">
                <div className="xmb-item-name">Refresh Library</div>
                <div className="xmb-item-sub">Scan for new titles</div>
              </div>
            </div>
          </>
        ) : (
          games.map((game, i) => (
            <GameCard
              key={game.path}
              name={game.name}
              emoji={game.emoji ?? "🎮"}
              selected={i === selectedIdx}
              onClick={() => {
                setSelectedIdx(i);
                if (i === selectedIdx) launchGame(game.path);
              }}
            />
          ))
        )}
      </div>

      {/* ── Right detail panel ── */}
      {selectedGame && (
        <div className="xmb-detail">
          <div className="xmb-detail-art">
            {launching ? "⚡" : selectedGame.emoji}
          </div>
          <div className="xmb-detail-title">
            {selectedGame.name.replace(/\.jar$/i, "")}
          </div>
          <div className="xmb-detail-meta">
            {launching ? "Launching…" : "J2ME · Mobile Classic"}
          </div>
        </div>
      )}

      {/* ── Bottom button hints ── */}
      <div className="xmb-hints">
        <div className="xmb-hint">
          <div className="xmb-hint-btn triangle">△</div>
          <div className="xmb-hint-label">Options</div>
        </div>
        <div className="xmb-hint">
          <div className="xmb-hint-btn circle">○</div>
          <div className="xmb-hint-label">Back</div>
        </div>
        <div className="xmb-hint">
          <div className="xmb-hint-btn cross">✕</div>
          <div className="xmb-hint-label">Launch</div>
        </div>
      </div>
    </div>
  );
}

export default App;

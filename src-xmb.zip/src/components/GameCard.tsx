import React from "react";

interface GameCardProps {
  name: string;
  onClick: () => void;
  selected: boolean;
  emoji: string;
}

const GameCard: React.FC<GameCardProps> = ({ name, onClick, selected, emoji }) => {
  return (
    <div
      onClick={onClick}
      className={`xmb-item ${selected ? "selected" : ""}`}
    >
      <div className="xmb-item-icon">
        <span>{emoji}</span>
      </div>
      <div className="xmb-item-info">
        <div className="xmb-item-name">{name.replace(/\.jar$/i, "")}</div>
        <div className="xmb-item-sub">J2ME · PlayStation Style</div>
      </div>
    </div>
  );
};

export default GameCard;
